/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan7;

/**
 *
 * @author royma
 */
public class Pisces extends MahklukHidup {
    int jmlSirip;
    String warna;
    
    String Kelas(){
        return "Kelas Pisces";
    }

    @Override
    String bernafas() {
        return "Bernafas Menggunakan Insang";
    }
    String berkembangbiak(){
        return "Bertelur";
    }
}
