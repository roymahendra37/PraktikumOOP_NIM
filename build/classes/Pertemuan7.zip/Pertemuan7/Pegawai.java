/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan7;

/**
 *
 * @author royma
 */
public abstract class Pegawai {
    //atribut
    int gapok;
    int T_trans;
    int lembur;
    int total;
    
    //method
    abstract int hitGaji(int jmlHadir, int jmlembur);
}
