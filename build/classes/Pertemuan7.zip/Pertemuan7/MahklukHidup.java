/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pertemuan7;

/**
 *
 * @author royma
 */
public abstract class MahklukHidup {
    
    //atribut
    int berat;
    int tinggi;
    
    //method
    abstract String bernafas();
    
    abstract String berkembangbiak();
    
    String judul(){
        return "Kelas Mahkluk Hidup";
    }
}
